package frozen.gambling.discord.games;

import frozen.gambling.discord.Constants;

public class FlowerGame extends DiceGame
{
  public FlowerGame() {
    result = random(0, Constants.FLOWERS.length - 1);
  }
  
  public int getResult()
  {
    return result;
  }
}
