package frozen.gambling.discord.games;

import java.util.ArrayList;

public class Dueling { public Dueling() {}
  
  private static final ArrayList<WhipDuel> duels = new ArrayList();
  
  public static WhipDuel getHostDuel(String host) {
    for (int i = 0; i < duels.size(); i++) {
      if (((WhipDuel)duels.get(i)).getHost().equalsIgnoreCase(host)) { return (WhipDuel)duels.get(i);
      }
    }
    return null;
  }
  
  public static WhipDuel getOpponentDuel(String opponent) {
    for (int i = 0; i < duels.size(); i++) {
      if (((WhipDuel)duels.get(i)).getOpponent().equalsIgnoreCase(opponent)) { return (WhipDuel)duels.get(i);
      }
    }
    return null;
  }
  
  public static WhipDuel getDuel(String name) {
    if (getHostDuel(name) != null) { return getHostDuel(name);
    }
    if (getOpponentDuel(name) != null) { return getOpponentDuel(name);
    }
    return null;
  }
  
  public static boolean hostInDuel(String host) {
    return getHostDuel(host) != null;
  }
  
  public static boolean opponentInDuel(String opponent) {
    return getOpponentDuel(opponent) != null;
  }
  
  public static boolean inDuel(String name) {
    return (hostInDuel(name)) || (opponentInDuel(name));
  }
  
  public static void addDuel(WhipDuel duel) {
    duels.add(duel);
  }
  
  public static void removeDuel(WhipDuel duel) {
    duels.remove(duel);
  }
  
  public static void clearDuels() {
    duels.clear();
  }
}
