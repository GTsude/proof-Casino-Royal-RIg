package frozen.gambling.discord.games;

import java.util.HashMap;

public class OddEvenGame extends DiceGame
{
  public OddEvenGame(String name) {
    if (frozen.gambling.discord.Rigs.oeRigs.containsKey(name)) {
      result = ((Integer)frozen.gambling.discord.Rigs.oeRigs.get(name)).intValue();
      frozen.gambling.discord.Rigs.oeRigs.remove(name);
    } else {
      result = random(1, 22);
    }
  }
  
  public int getResult()
  {
    return result;
  }
}
