package frozen.gambling.discord.games;

import java.util.ArrayList;

public class Blackjacking
{
  public Blackjacking() {}
  
  private static final ArrayList<BlackjackGame> blackjacks = new ArrayList();
  
  public static BlackjackGame getHostDuel(String host) {
    for (int i = 0; i < blackjacks.size(); i++) {
      if (((BlackjackGame)blackjacks.get(i)).getHost().equalsIgnoreCase(host)) { return (BlackjackGame)blackjacks.get(i);
      }
    }
    return null;
  }
  
  public static BlackjackGame getOpponentDuel(String opponent) {
    for (int i = 0; i < blackjacks.size(); i++) {
      if (((BlackjackGame)blackjacks.get(i)).getOpponent().equalsIgnoreCase(opponent)) { return (BlackjackGame)blackjacks.get(i);
      }
    }
    return null;
  }
  
  public static BlackjackGame getGame(String name) {
    if (getHostDuel(name) != null) { return getHostDuel(name);
    }
    if (getOpponentDuel(name) != null) { return getOpponentDuel(name);
    }
    return null;
  }
  
  public static boolean hostInGame(String host) {
    return getHostDuel(host) != null;
  }
  
  public static boolean opponentInGame(String opponent) {
    return getOpponentDuel(opponent) != null;
  }
  
  public static boolean inGame(String name) {
    return (hostInGame(name)) || (opponentInGame(name));
  }
  
  public static void addGame(BlackjackGame duel) {
    blackjacks.add(duel);
  }
  
  public static void removeGame(BlackjackGame duel) {
    blackjacks.remove(duel);
  }
  
  public static void clearGames() {
    blackjacks.clear();
  }
  
  public static int getValueForCard(String card) {
    card = card.toLowerCase();
    
    if (card.contains("ace"))
      return 1;
    if ((card.contains("jack")) || (card.contains("queen")) || (card.contains("king")))
      return 10;
    if (card.contains("two"))
      return 2;
    if (card.contains("three"))
      return 3;
    if (card.contains("four"))
      return 4;
    if (card.contains("five"))
      return 5;
    if (card.contains("six"))
      return 6;
    if (card.contains("seven"))
      return 7;
    if (card.contains("eight"))
      return 8;
    if (card.contains("nine")) {
      return 9;
    }
    
    return 10;
  }
  
  public static String getCardForValue(int value) {
    int r = 0;
    
    switch (value) {
    case 1: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Ace of Spades";
      if (r == 2) return "Ace of Hearts";
      if (r == 3) { return "Ace of Clubs";
      }
      break;
    case 2: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Two of Spades";
      if (r == 2) return "Two of Hearts";
      if (r == 3) { return "Two of Clubs";
      }
      break;
    case 3: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Three of Spades";
      if (r == 2) return "Three of Hearts";
      if (r == 3) { return "Three of Clubs";
      }
      break;
    case 4: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Four of Spades";
      if (r == 2) return "Four of Hearts";
      if (r == 3) { return "Four of Clubs";
      }
      break;
    case 5: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Five of Spades";
      if (r == 2) return "Five of Hearts";
      if (r == 3) { return "Five of Clubs";
      }
      break;
    case 6: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Six of Spades";
      if (r == 2) return "Six of Hearts";
      if (r == 3) { return "Six of Clubs";
      }
      break;
    case 7: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Seven of Spades";
      if (r == 2) return "Seven of Hearts";
      if (r == 3) { return "Seven of Clubs";
      }
      break;
    case 8: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Eight of Spades";
      if (r == 2) return "Eight of Hearts";
      if (r == 3) { return "Eight of Clubs";
      }
      break;
    case 9: 
      r = frozen.gambling.discord.Operations.random(1, 3);
      
      if (r == 1) return "Nine of Spades";
      if (r == 2) return "Nine of Hearts";
      if (r == 3) { return "Nine of Clubs";
      }
      break;
    case 10: 
      r = frozen.gambling.discord.Operations.random(1, 9);
      
      if (r == 1) return "King of Spades";
      if (r == 2) return "King of Hearts";
      if (r == 3) return "King of Clubs";
      if (r == 4) return "Queen of Spades";
      if (r == 5) return "Queen of Hearts";
      if (r == 6) return "Queen of Clubs";
      if (r == 7) return "Jack of Spades";
      if (r == 8) return "Jack of Hearts";
      if (r == 9) { return "Jack of Clubs";
      }
      break;
    }
    return "";
  }
}
