package frozen.gambling.discord.games;

import java.util.Random;

public abstract class DiceGame { protected int result;
  
  public DiceGame() {}
  
  protected Random r = new Random();
  
  public int random(int min, int max) {
    return r.nextInt(max) + min;
  }
  
  public String getFlowerType(String flower) {
    if ((flower.equalsIgnoreCase("purple")) || (flower.equalsIgnoreCase("blue")) || (flower.equalsIgnoreCase("pastel")))
      return "Cold";
    if ((flower.equalsIgnoreCase("Yellow")) || (flower.equalsIgnoreCase("Red")) || (flower.equalsIgnoreCase("Orange"))) {
      return "Hot";
    }
    
    return "Host Win";
  }
  
  public abstract int getResult();
}
