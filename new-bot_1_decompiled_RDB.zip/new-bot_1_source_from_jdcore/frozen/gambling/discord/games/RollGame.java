package frozen.gambling.discord.games;

import java.util.HashMap;

public class RollGame extends DiceGame
{
  public RollGame(String name) {
    if (frozen.gambling.discord.Rigs.rollRigs.containsKey(name)) {
      result = ((Integer)frozen.gambling.discord.Rigs.rollRigs.get(name)).intValue();
      frozen.gambling.discord.Rigs.rollRigs.remove(name);
    } else {
      result = random(1, 100);
    }
  }
  
  public int getResult()
  {
    return result;
  }
}
