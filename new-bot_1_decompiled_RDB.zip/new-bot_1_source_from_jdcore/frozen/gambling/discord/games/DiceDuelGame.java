package frozen.gambling.discord.games;

import java.util.HashMap;

public class DiceDuelGame extends DiceGame
{
  public DiceDuelGame(String name) {
    if (frozen.gambling.discord.Rigs.ddRigs.containsKey(name)) {
      result = ((Integer)frozen.gambling.discord.Rigs.ddRigs.get(name)).intValue();
      frozen.gambling.discord.Rigs.ddRigs.remove(name);
    } else {
      result = random(1, 12);
    }
  }
  
  public int getResult()
  {
    return result;
  }
}
