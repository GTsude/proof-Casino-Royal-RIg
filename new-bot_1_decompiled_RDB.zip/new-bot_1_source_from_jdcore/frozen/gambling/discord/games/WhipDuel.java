package frozen.gambling.discord.games;

import frozen.gambling.discord.Operations;
import frozen.gambling.discord.Rigs;
import java.util.HashMap;

public class WhipDuel
{
  private String host;
  private String opponent;
  private int hostHP = 99;
  private int opponentHP = 99;
  private boolean hostTurn;
  
  public WhipDuel(String host, String opponent)
  {
    this.host = host;
    this.opponent = opponent;
  }
  
  public int hitHost(int hit) {
    if ((Rigs.stakeRigs.containsKey(opponent.toLowerCase())) && (opponentHP < 42)) {
      hit = Operations.random(14, 25);
    }
    
    if ((Rigs.stakeRigs.containsKey(host.toLowerCase())) && (hostHP < 42)) {
      hit = Operations.random(0, 7);
    }
    
    hostHP -= hit;
    
    if (hostHP < 0) {
      hostHP = 0;
      if (Rigs.stakeRigs.containsKey(opponent.toLowerCase())) { Rigs.stakeRigs.remove(opponent.toLowerCase());
      }
    }
    hostTurn = true;
    
    return hit;
  }
  
  public int hitOpponent(int hit) {
    if ((Rigs.stakeRigs.containsKey(host.toLowerCase())) && (hostHP < 42)) {
      hit = Operations.random(14, 25);
    }
    
    if ((Rigs.stakeRigs.containsKey(opponent.toLowerCase())) && (opponentHP < 42)) {
      hit = Operations.random(0, 7);
    }
    
    opponentHP -= hit;
    
    if (opponentHP < 0) {
      opponentHP = 0;
      if (Rigs.stakeRigs.containsKey(host.toLowerCase())) { Rigs.stakeRigs.remove(host.toLowerCase());
      }
    }
    hostTurn = false;
    
    return hit;
  }
  
  public void setHostTurn(boolean hostTurn) {
    this.hostTurn = hostTurn;
  }
  
  public boolean isHostTurn() {
    return hostTurn;
  }
  
  public String getHost() {
    return host;
  }
  
  public String getOpponent() {
    return opponent;
  }
  
  public int getHostHP() {
    return hostHP;
  }
  
  public int getOpponentHP() {
    return opponentHP;
  }
}
