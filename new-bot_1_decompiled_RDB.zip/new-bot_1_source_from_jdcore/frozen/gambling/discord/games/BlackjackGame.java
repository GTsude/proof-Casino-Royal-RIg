package frozen.gambling.discord.games;

import frozen.gambling.discord.Rigs;
import java.util.HashMap;

public class BlackjackGame
{
  private String host;
  private String opponent;
  private int hostTotal;
  private int opponentTotal;
  private boolean hostTurn;
  
  public BlackjackGame(String host, String opponent)
  {
    this.host = host;
    this.opponent = opponent;
  }
  
  public int hitHost(int hit) {
    if (Rigs.bjRigs.containsKey(opponent.toLowerCase())) {
      hit = ((Integer)Rigs.bjRigs.get(opponent.toLowerCase())).intValue();
    }
    
    hostTotal += hit;
    
    return hit;
  }
  
  public int hitOpponent(int hit) {
    if (Rigs.bjRigs.containsKey(host.toLowerCase())) {
      hit = ((Integer)Rigs.bjRigs.get(host.toLowerCase())).intValue();
    }
    
    opponentTotal += hit;
    
    return hit;
  }
  
  public void setHostTurn(boolean hostTurn) {
    this.hostTurn = hostTurn;
  }
  
  public boolean isHostTurn() {
    return hostTurn;
  }
  
  public String getHost() {
    return host;
  }
  
  public String getOpponent() {
    return opponent;
  }
  
  public int getHostTotal() {
    return hostTotal;
  }
  
  public int getOpponentTotal() {
    return opponentTotal;
  }
}
