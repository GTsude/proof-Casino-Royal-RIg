package frozen.gambling.discord;

import java.util.HashMap;

public class Rigs { public Rigs() {}
  
  public static HashMap<String, Integer> rollRigs = new HashMap();
  
  public static HashMap<String, Integer> ddRigs = new HashMap();
  
  public static HashMap<String, Integer> oeRigs = new HashMap();
  
  public static HashMap<String, Integer> flowerRigs = new HashMap();
  
  public static HashMap<String, Integer> cchestRigs = new HashMap();
  
  public static HashMap<String, Integer> rchestRigs = new HashMap();
  
  public static HashMap<String, Integer> dchestRigs = new HashMap();
  
  public static HashMap<String, Integer> gchestRigs = new HashMap();
  
  public static HashMap<String, Integer> ageChestRigs = new HashMap();
  
  public static HashMap<String, Integer> stakeRigs = new HashMap();
  
  public static HashMap<String, Integer> bjRigs = new HashMap();
  
  public static HashMap<String, Integer> fpRigs = new HashMap();
  
  public static HashMap<String, Integer> rouletteRigs = new HashMap();
  
  public static void clearRigs() {
    rollRigs.clear();
    ddRigs.clear();
    oeRigs.clear();
    flowerRigs.clear();
    cchestRigs.clear();
    rchestRigs.clear();
    dchestRigs.clear();
    gchestRigs.clear();
    ageChestRigs.clear();
    stakeRigs.clear();
    bjRigs.clear();
    fpRigs.clear();
    rouletteRigs.clear();
  }
}
