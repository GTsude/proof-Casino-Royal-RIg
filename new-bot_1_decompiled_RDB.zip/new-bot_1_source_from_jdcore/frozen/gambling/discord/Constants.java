package frozen.gambling.discord;


public class Constants
{
  public static boolean PRIVATE;
  
  public static final String MAIN_TEXT_CHANNEL = "general";
  public static final String[] FLOWERS = { "Purple", "Blue", "Pastel", "Yellow", "Red", "Orange", "Rainbow" };
  
  public static final String[] COLD_FLOWERS = { "Purple", "Blue", "Pastel" };
  public static final String[] HOT_FLOWERS = { "Yellow", "Red", "Orange" };
  
  public static final String[] CARDS = { "Ace of Spades", "Two of Spades", "Three of Spades", "Four of Spades", "Five of Spades", "Six of Spades", "Seven of Spades", 
    "Eight of Spades", "Nine of Spades", "Ten of Spades", "Jack of Spades", "Queen of Spades", "King of Spades", "Ace of Diamonds", "Two of Diamonds", "Three of Diamonds", 
    "Four of Diamonds", "Five of Diamonds", "Six of Diamonds", "Seven of Diamonds", "Eight of Diamonds", "Nine of Diamonds", "Ten of Diamonds", "Jack of Diamonds", "Queen of Diamonds", 
    "King of Diamonds", "Ace of Hearts", "Two of Hearts", "Three of Hearts", "Four of Hearts", "Five of Hearts", "Six of Hearts", "Seven of Hearts", 
    "Eight of Hearts", "Nine of Hearts", "Ten of Hearts", "Jack of Hearts", "Queen of Hearts", "King of Hearts", "Ace of Clubs", "Two of Clubs", "Three of Clubs", 
    "Four of Clubs", "Five of Clubs", "Six of Clubs", "Seven of Clubs", "Eight of Clubs", "Nine of Clubs", "Ten of Clubs", "Jack of Clubs", "Queen of Clubs", 
    "King of Clubs" };
  



  public static final String[] CLUE_CHEST = { "100k Coins", "Peaceful Blessing", "Wizard Robe Top (T)", "Amulet of Magic (T)", "White Beret", "BLack Beret", "Red Beret", 
    "Red Elegant Shirt", "Red Elegant Legs", "Black Elegant Shirt", "Black Elegant legs", "White Cavalier", "Black Cavalier", "Tan Cavalier", "Wizard Robe (T) Set", 
    "Wizard Robe (G) Set", "Bronze Armour (T) Set", "Bronze Armour (G) Set", "Golden Chefï؟½s Hat", "Golden Apron", "Robin Hood Hat", "2x Gilded full helm", "2x Gilded Platebody", 
    "Monk robe top (G)", "10M Coins", "Monk Robes (G) Set" };
  
  public static final String[] CLUE_CHEST_LEVEL_1 = { "100k Coins", "Peaceful Blessing", "Wizard Robe Top (T)", "Amulet of Magic (T)", "White Beret", "BLack Beret", "Red Beret", 
    "Red Elegant Shirt", "Red Elegant Legs", "Black Elegant Shirt", "Black Elegant legs", "White Cavalier", "Black Cavalier", "Tan Cavalier" };
  
  public static final String[] CLUE_CHEST_LEVEL_2 = { "Wizard Robe (T) Set", "Wizard Robe (G) Set", "Bronze Armour (T) Set", "Bronze Armour (G) Set", "Golden Chefï؟½s Hat", "Golden Apron" };
  
  public static final String[] CLUE_CHEST_LEVEL_3 = { "Robin Hood Hat", "2x Gilded full helm", "2x Gilded Platebody", "Monk robe top (G)" };
  
  public static final String[] CLUE_CHEST_LEVEL_4 = { "10M Coins", "Monk Robes (G) Set" };
  








  public static final String[] RUNE_CHEST = { "Rune Scimitar", "Rune Kite", "Rune Platelegs", "Rune Platebody", "Rune Full Helm", "Saradomin armour set", "Guthix armour set", 
    "Zamorak armour set", "Rune Armour (G) Set", "Rune Armour (T) Set", "Rune Armour Set", "2x Gilded Full Helm", "2x Gilded Platebody", "2x Gilded Kite", 
    "2x Gilded Scimitar", "2x Gilded armour set" };
  
  public static final String[] RUNE_CHEST_LEVEL_1 = { "Rune Scimitar", "Rune Kite", "Rune Platelegs", "Rune Platebody", "Rune Full Helm" };
  
  public static final String[] RUNE_CHEST_LEVEL_2 = { "Saradomin armour set", "Guthix armour set", "Zamorak armour set", "Rune Armour (G) Set", "Rune Armour (T) Set", "Rune Armour Set" };
  
  public static final String[] RUNE_CHEST_LEVEL_3 = { "2x Gilded Full Helm", "2x Gilded Platebody", "2x Gilded Kite" };
  
  public static final String[] RUNE_CHEST_LEVEL_4 = { "2x Gilded Scimitar", "2x Gilded armour set" };
  







  public static final String[] DRAGON_CHEST = { "Dragon Scimitar", "Dragon Platelegs", "Dragon Sq Shield", "Dragon Boots", "Dragon Longsword", "Dragon 2h Sword", 
    "Dragon Battleaxe", "Dragon Axe", "Dragon Pickaxe", "Dragon Chainbody", "1000x Dragon Arrows", "2x Dragon Impling", "2x Dragon Chainbody", "2000x Dragon Arrows", 
    "4x Dragon Implings", "Dragon Full Helm", "Dragon Warhammer", "Dragon Hunter Crossbow", "Dragon Harpoon" };
  
  public static final String[] DRAGON_CHEST_LEVEL_1 = { "Dragon Scimitar", "Dragon Platelegs", "Dragon Sq Shield", "Dragon Boots", "Dragon Longsword", "Dragon 2h Sword", 
    "Dragon Battleaxe", "Dragon Axe" };
  
  public static final String[] DRAGON_CHEST_LEVEL_2 = { "Dragon Pickaxe", "Dragon Chainbody", "1000x Dragon Arrows", "2x Dragon Impling" };
  
  public static final String[] DRAGON_CHEST_LEVEL_3 = { "2x Dragon Chainbody", "2000x Dragon Arrows", "4x Dragon Implings" };
  
  public static final String[] DRAGON_CHEST_LEVEL_4 = { "Dragon Full Helm", "Dragon Warhammer", "Dragon Hunter Crossbow", "Dragon Harpoon" };
  






  public static final String[] GOD_CHEST = { "Dharokï؟½s Platebody", "Guthanï؟½s Platebody", "Veracï؟½s Brassard", "Toragï؟½s Platebody", "2x Saradomin Sword", "Bandos Godsword", 
    "Dharokï؟½s armour set", "Toragï؟½s armour set", "Bandos Chestplate", "Bandos Tassets", "Armadyl Crossbow", "Armadyl Chestplate", "Guthanï؟½s Armour Set", 
    "Armadyl Godsword", "Saradomin Godsword", "Zamorak Godsword" };
  
  public static final String[] GOD_CHEST_LEVEL_1 = { "Dharokï؟½s Platebody", "Guthanï؟½s Platebody", "Veracï؟½s Brassard", "Toragï؟½s Platebody" };
  
  public static final String[] GOD_CHEST_LEVEL_2 = { "2x Saradomin Sword", "Bandos Godsword", "Dharokï؟½s armour set", "Toragï؟½s armour set" };
  
  public static final String[] GOD_CHEST_LEVEL_3 = { "Bandos Chestplate", "Bandos Tassets", "Armadyl Crossbow", "Armadyl Chestplate", "Guthanï؟½s Armour Set" };
  
  public static final String[] GOD_CHEST_LEVEL_4 = { "Armadyl Godsword", "Saradomin Godsword", "Zamorak Godsword" };
  







  public static final String[] AGE_CHEST = { "3rd Age Range Coif", "3rd Age Full Helm", "3rd Age Robe Bottom", "3rd Age Range Legs", "3rd Age Range Top", "3rd Age Robe Top", 
    "3rd Age Kite", "3rd Age Mage Hat", "3rd Age Platebody", "3rd Age Platelegs", "3rd Age armour set" };
  
  public static final String[] AGE_CHEST_LEVEL_1 = { "3rd Age Range Coif", "3rd Age Full Helm", "3rd Age Robe Bottom", "3rd Age Range Legs", "3rd Age Range Top" };
  
  public static final String[] AGE_CHEST_LEVEL_2 = { "3rd Age Robe Top", "3rd Age Kite", "3rd Age Mage Hat" };
  
  public static final String[] AGE_CHEST_LEVEL_3 = { "3rd Age Platebody", "3rd Age Platelegs" };
  
  public static final String[] AGE_CHEST_LEVEL_4 = { "3rd Age armour set" };
  
  public Constants() {}
}
