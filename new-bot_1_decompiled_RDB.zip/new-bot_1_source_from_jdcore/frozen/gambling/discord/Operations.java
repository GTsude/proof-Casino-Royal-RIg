package frozen.gambling.discord;

import java.util.concurrent.ThreadLocalRandom;

public class Operations {
  public Operations() {}
  
  public static int random(int min, int max) { return ThreadLocalRandom.current().nextInt(min, max + 1); }
}
