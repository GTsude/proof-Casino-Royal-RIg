package frozen.gambling.discord;

import frozen.gambling.discord.events.MessageListener;
import javax.security.auth.login.LoginException;
import net.dv8tion.jda.core.AccountType;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.JDABuilder;

public class Main
{
  private JDA jda;
  
  public Main()
  {
    try
    {
      jda = new JDABuilder(AccountType.BOT).setToken("NDYwOTAwNzA3MzY1NjgzMjEw.DhLexg.W6yY9o2mNY8ulk15YbyK62DbljE").buildBlocking();
      jda.setAutoReconnect(true);
      
      jda.addEventListener(new Object[] { new MessageListener() });
    } catch (LoginException|IllegalArgumentException|InterruptedException e) {
      e.printStackTrace();
    }
  }
  
  public static void main(String[] args) {
    new Main();
  }
}
