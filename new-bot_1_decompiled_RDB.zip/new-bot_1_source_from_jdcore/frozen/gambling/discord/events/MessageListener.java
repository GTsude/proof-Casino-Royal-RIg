package frozen.gambling.discord.events;

import frozen.gambling.discord.Constants;
import frozen.gambling.discord.Rigs;
import frozen.gambling.discord.games.BlackjackGame;
import frozen.gambling.discord.games.Blackjacking;
import frozen.gambling.discord.games.DiceDuelGame;
import frozen.gambling.discord.games.Dueling;
import frozen.gambling.discord.games.FlowerGame;
import frozen.gambling.discord.games.OddEvenGame;
import frozen.gambling.discord.games.RollGame;
import frozen.gambling.discord.games.WhipDuel;
import java.awt.Color;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.entities.Channel;
import net.dv8tion.jda.core.entities.ChannelType;
import net.dv8tion.jda.core.entities.Member;
import net.dv8tion.jda.core.entities.Message;
import net.dv8tion.jda.core.entities.MessageChannel;
import net.dv8tion.jda.core.entities.TextChannel;
import net.dv8tion.jda.core.entities.User;
import net.dv8tion.jda.core.events.message.MessageReceivedEvent;
import net.dv8tion.jda.core.requests.restaction.MessageAction;

public class MessageListener extends net.dv8tion.jda.core.hooks.ListenerAdapter
{
  private JDA jda;
  private Random r = new Random();
  
  private boolean giveawayActive;
  
  private String giveawayCreator;
  
  private ArrayList<String> giveaway = new ArrayList();
  
  public MessageListener() {}
  
  public void onMessageReceived(MessageReceivedEvent e) { jda = e.getJDA();
    
    User author = e.getAuthor();
    Message message = e.getMessage();
    MessageChannel channel = e.getChannel();
    
    String parsedName = author.getName().replaceAll("\\s+", "");
    String msg = message.getContentDisplay();
    
    boolean isBot = author.isBot();
    
    if (!isBot) {
      if ((Constants.PRIVATE) && (!author.getName().equalsIgnoreCase("Prozen"))) { return;
      }
      if (channel.getType().equals(ChannelType.PRIVATE)) {
        Channel c = getTextChannel(jda, "general");
        Member m = getMemberFromChannel(c, parsedName);
        
        System.out.println(parsedName);
        
        if ((!author.getName().equalsIgnoreCase("arnold")) && 
          (!isStaff(m))) {
          System.out.println(parsedName);
          return;
        }
        

        msg = msg.toLowerCase();
        
        String[] args = msg.split(" ");
        
        if (args.length == 3) {
          String username = args[0];
          String game = args[1];
          String textValue = args[2];
          
          int value = 0;
          
          if (game.equalsIgnoreCase("roll")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 100)) {
              Rigs.rollRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("dd")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 12)) {
              Rigs.ddRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("oe")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 22)) {
              Rigs.oeRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("flower")) {
            if (textValue.equalsIgnoreCase("hot")) {
              Rigs.flowerRigs.put(username, Integer.valueOf(1));
            } else if (textValue.equalsIgnoreCase("cold")) {
              Rigs.flowerRigs.put(username, Integer.valueOf(2));
            } else if (textValue.equalsIgnoreCase("host")) {
              Rigs.flowerRigs.put(username, Integer.valueOf(3));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("cchest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.cchestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("rchest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.rchestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("dchest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.dchestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("gchest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.gchestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("3achest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.ageChestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("stake")) {
            if (textValue.equalsIgnoreCase("win")) {
              Rigs.stakeRigs.put(username, Integer.valueOf(1));
            } else if (!textValue.equalsIgnoreCase("lose"))
            {

              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("bj")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 10)) {
              Rigs.bjRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("fp")) {
            if (textValue.equalsIgnoreCase("1p")) {
              Rigs.fpRigs.put(username, Integer.valueOf(1));
            } else if (textValue.equalsIgnoreCase("2p")) {
              Rigs.fpRigs.put(username, Integer.valueOf(2));
            } else if (textValue.equalsIgnoreCase("3oak")) {
              Rigs.fpRigs.put(username, Integer.valueOf(3));
            } else if (textValue.equalsIgnoreCase("4oak")) {
              Rigs.fpRigs.put(username, Integer.valueOf(4));
            } else if (textValue.equalsIgnoreCase("5oak")) {
              Rigs.fpRigs.put(username, Integer.valueOf(5));
            }
          } else if (game.equalsIgnoreCase("spin")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 0) && (value <= 38)) {
              Rigs.rouletteRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else {
            channel.sendMessage("[ERROR] Invalid game.").queue();
            return;
          }
          
          if (value == 0) {
            channel.sendMessage("[RIG] Registered Rig Successfully - (" + username + ", " + game + ", " + textValue + ")").queue();
          } else {
            channel.sendMessage("[RIG] Registered Rig Successfully - (" + username + ", " + game + ", " + value + ")").queue();
          }
        } else {
          channel.sendMessage("[ERROR] Invalid Syntax. Example Usage - @username game value").queue();
        }
      }
      else
      {
        if (msg.equalsIgnoreCase("!rules"))
        {







          channel.sendMessage("**Current Rules:**\n\n\n-!bjrules (blackjack)\n\n-!rollrules (54x2 rules)\n\n-!oerules (odd/even)\n\n-!ddrules (dice duel)\n\n-!flowerrules (hot cold)\n\n-!chestrules (Chest games)\n\n-!fprules (flower poker)\n\n-!whiprules (staking)").queue();
        } else if (msg.equalsIgnoreCase("!bjrules"))
        {

          channel.sendMessage("**Blackjack Rules:**\n\nClosest to 21 wins, over 21 is bust (lose).\nStart by gambler typing !bj and adding card values (face cards worth 10, ace worth 1). Type !hit to be dealt another card and tell dealer/house, !stay to keep current value.").queue();
        } else if (msg.equalsIgnoreCase("!rollrules"))
        {



          channel.sendMessage("**54x2 Rules:**\n\nHost rolls a percentile (1-100) die.\n1-54, host wins.\n55-100, gambler wins.\nX2 payout.").queue();
        } else if (msg.equalsIgnoreCase("!oerules"))
        {




          channel.sendMessage("**Odd/Even Rules:**\n\nHost rolls a hits a guard (1-22) and gambler guesses odd or even.\nOdd: 3,5,7,9,11,13,15,17,19,21\nEven: 54,6,8,10,12,14,16,18,20,22\nHost Win: 1,2X2 Payout.").queue();
        } else if (msg.equalsIgnoreCase("!ddrules"))
        {


          channel.sendMessage("**Dice Duel Rules:****Dice Duel Rules:**\n\nHost and gambler both roll two-six sided (2-12) dice with !dd command.\nHighest roll wins with 10% commission on the pot and tie being host win. 10% commission with unlimited rolls when wagered (see !wagerrules for info).\nX2 Payout and 1x Tie = Host win").queue();
        } else if (msg.equalsIgnoreCase("!flowerrules"))
        {



          channel.sendMessage("**Hot/Cold Rules:**\n\nGambler bets if flower picked by host is a hot or cold color, (rainbow a is host win).\nHot: Red, Yellow, Orange.\nCold: Blue, Pastel, Purple.\nX2 Payout").queue();
        } else if (msg.equalsIgnoreCase("!fprules"))
        {


          channel.sendMessage("**Flower Poker Rules:**\n\nBet on who has the best hand of 5 flowers, command is !fp. Worst to best hands are:\nBust (no same colors) < 1 Pair < 2 Pair < 3 Of A Kind < Full House (3oak & 1 pair) < 4 Of A Kind < 5 Of A Kind.\nX2 Tie is host win.").queue();
        } else if (msg.equalsIgnoreCase("!whiprules"))
        {
          channel.sendMessage("**Whip Rules:**\n\nGambler and host will both start with 99hp, host gets PID (so will start the game and get last hit).  Minimum hit is 0, Max hit is 25. Game is started by host doing !duel, gambler does !whip, ends when either player is 0 HP.").queue();
        } else if (msg.equalsIgnoreCase("!chestrules"))
        {
          channel.sendMessage("**Chest Rules:**\n\nChest games are always winners! Win the shown prize after a host does the respective command, you can pick from these choices: Clue - 500k buy-in [!cchest], Rune - 1m buy-in [!rchest], Dragon - 2m buy-in [!dchest], God - 5m buy-in [!gchest], Third Age - 50m buy-in [!3achest]. Pricing listed is for OldSchool Runescape, for RS3 pricing simply PM a host.").queue();
        } else if (msg.equalsIgnoreCase("!wagerrules"))
        {
          channel.sendMessage("**Wagers:**\n\nWagers must be placed through a ranked host DO NOT DIRECTLY TRADE ANY GAMBLER YOUR CASH. Ranks will take a 10% commision for middlemanning a wager and payout to the respective winner.").queue();
        } else if (msg.equalsIgnoreCase("!rouletterules")) {
          channel.sendMessage("Gambler bets on Green [0], Black [odd numbers], Red [even numbers]. Green = 3x Payout, Black & Red = 2x Payout").queue();
        }
        




        if (msg.equalsIgnoreCase("!roll")) {
          RollGame g = new RollGame(e.getMember().getEffectiveName().toLowerCase());
          

          EmbedBuilder eb = new EmbedBuilder();
          eb.setTitle("You Just Rolled The Dice", null);
          eb.setColor(Color.orange);
          eb.setColor(new Color(16744448));
          eb.setColor(new Color(219, 139, 0));
          if (g.getResult() >= 55) {
            eb.setDescription("Host: " + author.getAsMention() + "\n" + "You Won [" + g.getResult() + "] :white_check_mark:");
          } else {
            eb.setDescription("Host: " + author.getAsMention() + "\n" + "You Lose [" + g.getResult() + "] :no_entry:");
          }
          eb.addBlankField(false);
          eb.addField("Range :", "1-100", false);
          eb.setThumbnail("https://cdn.discordapp.com/attachments/332635571111329795/460975452748513300/dice_bag.png");
          channel.sendMessage(eb.build()).queue();
        }
        


        if (msg.equalsIgnoreCase("!dd")) {
          DiceDuelGame g = new DiceDuelGame(e.getMember().getEffectiveName().toLowerCase());
          

          EmbedBuilder eb1 = new EmbedBuilder();
          eb1.setTitle("Duel Dice", null);
          eb1.setColor(Color.orange);
          eb1.setColor(new Color(16744448));
          eb1.setColor(new Color(219, 139, 0));
          eb1.setDescription("Host: " + author.getAsMention() + "\n" + "You Rolled [" + g.getResult() + "] :white_check_mark:");
          eb1.addBlankField(false);
          eb1.addField("Range :", "1-12", false);
          eb1.setThumbnail("https://cdn.discordapp.com/attachments/332635571111329795/460975443273580565/dice.png");
          channel.sendMessage(eb1.build()).queue();

        }
        else if (msg.equalsIgnoreCase("!oe")) {
          OddEvenGame g = new OddEvenGame(e.getMember().getEffectiveName().toLowerCase());
          

          EmbedBuilder eb1 = new EmbedBuilder();
          eb1.setTitle(":crossed_swords:SomeOne Is Hitting The Guard!", null);
          eb1.setColor(Color.orange);
          eb1.setColor(new Color(16744448));
          eb1.setColor(new Color(219, 139, 0));
          eb1.setDescription(author.getAsMention() + " Just Hit A Guard With " + "***" + g.getResult() + "***");
          eb1.addField("***Range***: ", " 1 - 22 ", false);
          eb1.addBlankField(false);
          eb1.setThumbnail("https://images-ext-2.discordapp.net/external/DTbhY6HPUy_YMkIZQ6NeplUuImqgosz3SIrPnJ9ue08/%3Fcb%3D20170428215816/https/vignette.wikia.nocookie.net/runescape2/images/c/c9/Abyssal_whip_%2528fake%2529_detail.png/revision/latest?width=614&height=586");
          channel.sendMessage(eb1.build()).queue();


        }
        else if (msg.equalsIgnoreCase("!flower")) {
          FlowerGame g = new FlowerGame();
          
          String name = e.getMember().getEffectiveName().toLowerCase();
          
          String flower = Constants.FLOWERS[g.getResult()];
          String flowerType = g.getFlowerType(flower);
          
          if (Rigs.flowerRigs.containsKey(name)) {
            int value = ((Integer)Rigs.flowerRigs.get(name)).intValue();
            
            switch (value) {
            case 1: 
              flower = Constants.HOT_FLOWERS[random(0, Constants.HOT_FLOWERS.length - 1)];
              break;
            
            case 2: 
              flower = Constants.COLD_FLOWERS[random(0, Constants.COLD_FLOWERS.length - 1)];
              break;
            
            case 3: 
              flower = "Rainbow";
            }
            
            
            flowerType = g.getFlowerType(flower);
            
            Rigs.flowerRigs.remove(name);
          }
          

          EmbedBuilder eb1 = new EmbedBuilder();
          eb1.setTitle("Picking Flower!", null);
          eb1.setColor(Color.orange);
          eb1.setColor(new Color(16744448));
          eb1.setColor(new Color(219, 139, 0));
          eb1.setDescription("Host: " + author.getAsMention() + "\n" + "Picked : " + "**" + flower + "**");
          eb1.addField("Type :", flowerType, false);
          eb1.addBlankField(false);
          eb1.setThumbnail("https://cdn.discordapp.com/attachments/332635571111329795/461003024559505418/Nasturtiums_detail.png");
          channel.sendMessage(eb1.build()).queue();


        }
        else if (msg.equalsIgnoreCase("!fp")) {
          String[] flowers = { Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
          String flower = Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)];
          
          if (Rigs.fpRigs.containsKey(e.getMember().getEffectiveName().toLowerCase())) {
            int value = ((Integer)Rigs.fpRigs.get(e.getMember().getEffectiveName().toLowerCase())).intValue();
            
            switch (value) {
            case 1: 
              if (random(1, 2) == 1) {
                flowers = new String[] { flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              } else {
                flowers = new String[] { Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], flower, flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              }
              break;
            
            case 2: 
              String f1 = Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)];
              flowers = new String[] { flower, flower, f1, f1, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              break;
            
            case 3: 
              flowers = new String[] { flower, flower, flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              break;
            
            case 4: 
              flowers = new String[] { flower, flower, flower, flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              break;
            
            case 5: 
              flowers = new String[] { flower, flower, flower, flower, flower };
            }
            
            
            Rigs.fpRigs.remove(e.getMember().getEffectiveName().toLowerCase());
          }
          


          EmbedBuilder eb1 = new EmbedBuilder();
          eb1.setTitle("Picking Flowers!", null);
          eb1.setColor(Color.orange);
          eb1.setColor(new Color(16744448));
          eb1.setColor(new Color(219, 139, 0));
          eb1.setDescription("Host: " + author.getAsMention() + "\n" + "Picked : " + flowers[0] + " " + flowers[1] + " " + flowers[2] + " " + flowers[3] + " " + flowers[4] + " ");
          eb1.addBlankField(false);
          eb1.setThumbnail("https://cdn.discordapp.com/attachments/332635571111329795/461011461393874946/latest.png");
          channel.sendMessage(eb1.build()).queue();



        }
        else if ((msg.toLowerCase().startsWith("!duel")) && (isStaff(e.getMember()))) {
          if (msg.contains("@")) {
            String target = msg.substring(7);
            
            if ((target != null) && 
              (!Dueling.inDuel(author.getName())) && (!Dueling.inDuel(target))) {
              WhipDuel duel = new WhipDuel(e.getMember().getEffectiveName(), target);
              
              Dueling.addDuel(duel);
              
              int hit = random(0, 25);
              
              duel.hitOpponent(hit);
              


              EmbedBuilder eb1 = new EmbedBuilder();
              eb1.setTitle(":crossed_swords: You Commenced A Duel With " + target, null);
              eb1.setColor(Color.orange);
              eb1.setColor(new Color(16744448));
              eb1.setColor(new Color(219, 139, 0));
              eb1.setDescription(target + " Got A Hit With " + "***" + hit + "***" + "\n" + target + "'s HP Now Is " + "***" + duel.getOpponentHP() + "***");
              eb1.addField("For Another Hit Type", "***!whip*** ", false);
              eb1.addBlankField(false);
              eb1.setThumbnail("https://images-ext-2.discordapp.net/external/DTbhY6HPUy_YMkIZQ6NeplUuImqgosz3SIrPnJ9ue08/%3Fcb%3D20170428215816/https/vignette.wikia.nocookie.net/runescape2/images/c/c9/Abyssal_whip_%2528fake%2529_detail.png/revision/latest?width=614&height=586");
              channel.sendMessage(eb1.build()).queue();
            }
            
          }
          

        }
        else if (msg.equalsIgnoreCase("!whip")) {
          String name = e.getMember().getEffectiveName();
          if (Dueling.inDuel(name)) {
            WhipDuel duel = Dueling.getDuel(name);
            
            if (duel != null) {
              if (duel.getHost().equalsIgnoreCase(name)) {
                if (duel.isHostTurn()) {
                  int hit = random(0, 25);
                  
                  hit = duel.hitOpponent(hit);
                  

                  EmbedBuilder eb1 = new EmbedBuilder();
                  eb1.setTitle(" :crossed_swords: " + duel.getOpponent() + " Get's A Hit", null);
                  eb1.setColor(Color.orange);
                  eb1.setColor(new Color(16744448));
                  eb1.setColor(new Color(219, 139, 0));
                  eb1.setDescription(author.getAsMention() + " Hits " + "***" + duel.getOpponent() + "\n" + " ***" + "And His HP Now Is " + "***" + duel.getOpponentHP() + "***");
                  eb1.addField("For Another Hit Type", "***!whip*** ", false);
                  eb1.addBlankField(false);
                  eb1.setThumbnail("https://media.discordapp.net/attachments/332635571111329795/461185045131165699/images_-_Copy.png");
                  channel.sendMessage(eb1.build()).queue();
                  


                  if (duel.getOpponentHP() <= 0) {
                    Dueling.removeDuel(duel);
                    

                    EmbedBuilder eb2 = new EmbedBuilder();
                    eb2.setTitle(" :crossed_swords: :first_place: ***" + duel.getHost() + "***" + " Won the Duel Against" + "***" + duel.getOpponent() + "***", null);
                    eb2.setColor(Color.orange);
                    eb2.setColor(new Color(16744448));
                    eb2.setColor(new Color(219, 139, 0));
                    eb2.setDescription("Congratz " + duel.getHost() + " :confetti_ball: :tada: :clap: " + "\n" + "***Sorry*** " + duel.getOpponent() + " Better Luck Next Time");
                    eb2.addBlankField(false);
                    eb2.setThumbnail("https://images-ext-2.discordapp.net/external/DTbhY6HPUy_YMkIZQ6NeplUuImqgosz3SIrPnJ9ue08/%3Fcb%3D20170428215816/https/vignette.wikia.nocookie.net/runescape2/images/c/c9/Abyssal_whip_%2528fake%2529_detail.png/revision/latest?width=614&height=586");
                    channel.sendMessage(eb2.build()).queue();
                  }
                  
                }
              }
              else if ((duel.getOpponent().equalsIgnoreCase(name)) && 
                (!duel.isHostTurn())) {
                int hit = random(0, 25);
                
                hit = duel.hitHost(hit);
                


                EmbedBuilder eb1 = new EmbedBuilder();
                eb1.setTitle(" :crossed_swords: " + duel.getHost() + " Get's A Hit", null);
                eb1.setColor(Color.orange);
                eb1.setColor(new Color(16744448));
                eb1.setColor(new Color(219, 139, 0));
                eb1.setDescription(duel.getOpponent() + " Hits " + "***" + duel.getHost() + "\n" + " ***" + "And His HP Now Is " + "***" + duel.getHostHP() + "***");
                eb1.addField("For Another Hit Type", "***!whip*** ", false);
                eb1.addBlankField(false);
                eb1.setThumbnail("https://images-ext-2.discordapp.net/external/DTbhY6HPUy_YMkIZQ6NeplUuImqgosz3SIrPnJ9ue08/%3Fcb%3D20170428215816/https/vignette.wikia.nocookie.net/runescape2/images/c/c9/Abyssal_whip_%2528fake%2529_detail.png/revision/latest?width=614&height=586");
                channel.sendMessage(eb1.build()).queue();
                



                if (duel.getHostHP() <= 0) {
                  Dueling.removeDuel(duel);
                  

                  EmbedBuilder eb2 = new EmbedBuilder();
                  eb2.setTitle(" :crossed_swords: :first_place: ***" + duel.getOpponent() + "***" + " Won the Duel Against" + "***" + duel.getHost() + "***", null);
                  eb2.setColor(Color.orange);
                  eb2.setColor(new Color(16744448));
                  eb2.setColor(new Color(219, 139, 0));
                  eb2.setDescription("Congratz " + duel.getOpponent() + " :confetti_ball: :tada: :clap: " + "\n" + "***Sorry*** " + duel.getHost() + " Better Luck Next Time");
                  eb2.addBlankField(false);
                  eb2.setThumbnail("https://images-ext-2.discordapp.net/external/DTbhY6HPUy_YMkIZQ6NeplUuImqgosz3SIrPnJ9ue08/%3Fcb%3D20170428215816/https/vignette.wikia.nocookie.net/runescape2/images/c/c9/Abyssal_whip_%2528fake%2529_detail.png/revision/latest?width=614&height=586");
                  channel.sendMessage(eb2.build()).queue();
                }
                
              }
              
            }
          }
        }
        else if (msg.equalsIgnoreCase("!cchest")) {
          String item = Constants.CLUE_CHEST[random(0, Constants.CLUE_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.cchestRigs.containsKey(username)) {
            switch (((Integer)Rigs.cchestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.CLUE_CHEST_LEVEL_1[random(0, Constants.CLUE_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.CLUE_CHEST_LEVEL_2[random(0, Constants.CLUE_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.CLUE_CHEST_LEVEL_3[random(0, Constants.CLUE_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.CLUE_CHEST_LEVEL_4[random(0, Constants.CLUE_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.cchestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[Clue]** Chest :key:").queue();
        } else if (msg.equalsIgnoreCase("!rchest")) {
          String item = Constants.RUNE_CHEST[random(0, Constants.RUNE_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.rchestRigs.containsKey(username)) {
            switch (((Integer)Rigs.rchestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.RUNE_CHEST_LEVEL_1[random(0, Constants.RUNE_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.RUNE_CHEST_LEVEL_2[random(0, Constants.RUNE_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.RUNE_CHEST_LEVEL_3[random(0, Constants.RUNE_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.RUNE_CHEST_LEVEL_4[random(0, Constants.RUNE_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.rchestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[Rune]** Chest :key:").queue();
        } else if (msg.equalsIgnoreCase("!dchest")) {
          String item = Constants.DRAGON_CHEST[random(0, Constants.DRAGON_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.dchestRigs.containsKey(username)) {
            switch (((Integer)Rigs.dchestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.DRAGON_CHEST_LEVEL_1[random(0, Constants.DRAGON_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.DRAGON_CHEST_LEVEL_2[random(0, Constants.DRAGON_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.DRAGON_CHEST_LEVEL_3[random(0, Constants.DRAGON_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.DRAGON_CHEST_LEVEL_4[random(0, Constants.DRAGON_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.dchestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[Dragon]** Chest :key:").queue();
        } else if (msg.equalsIgnoreCase("!gchest")) {
          String item = Constants.GOD_CHEST[random(0, Constants.GOD_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.gchestRigs.containsKey(username)) {
            switch (((Integer)Rigs.gchestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.GOD_CHEST_LEVEL_1[random(0, Constants.GOD_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.GOD_CHEST_LEVEL_2[random(0, Constants.GOD_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.GOD_CHEST_LEVEL_3[random(0, Constants.GOD_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.GOD_CHEST_LEVEL_4[random(0, Constants.GOD_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.gchestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[God]** Chest :key:").queue();
        } else if (msg.equalsIgnoreCase("!3achest")) {
          String item = Constants.AGE_CHEST[random(0, Constants.AGE_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.ageChestRigs.containsKey(username)) {
            switch (((Integer)Rigs.ageChestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.AGE_CHEST_LEVEL_1[random(0, Constants.AGE_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.AGE_CHEST_LEVEL_2[random(0, Constants.AGE_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.AGE_CHEST_LEVEL_3[random(0, Constants.AGE_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.AGE_CHEST_LEVEL_4[random(0, Constants.AGE_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.ageChestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[3rd Age]** Chest :key:").queue();
        } else if ((msg.startsWith("!bj")) && (msg.contains("@")) && (isStaff(e.getMember()))) {
          String target = msg.substring(5);
          
          if (target != null) {
            BlackjackGame g = new BlackjackGame(e.getMember().getEffectiveName(), target);
            
            Blackjacking.addGame(g);
            
            channel.sendMessage("**[" + author.getAsMention() + "]** started a Blackjack game with **[" + target + "]**").queue();
          }
        } else if (msg.equalsIgnoreCase("!hit")) {
          if (Blackjacking.inGame(e.getMember().getEffectiveName())) {
            BlackjackGame g = Blackjacking.getGame(e.getMember().getEffectiveName());
            
            if (g != null) {
              String card = Constants.CARDS[random(0, Constants.CARDS.length - 1)];
              
              String emote = "";
              
              int total = 0;
              int hit = 0;
              
              if (card.contains("Clubs")) { emote = ":clubs:";
              }
              else if (card.contains("Hearts")) { emote = ":hearts:";
              }
              else if (card.contains("Spade")) { emote = ":spades:";
              }
              else if (card.contains("Diamond")) { emote = ":diamonds:";
              }
              if (g.isHostTurn()) {
                hit = g.hitOpponent(Blackjacking.getValueForCard(card));
                total = g.getOpponentTotal();
              } else {
                if (g.getHost().equalsIgnoreCase(e.getMember().getEffectiveName())) return;
                hit = g.hitHost(Blackjacking.getValueForCard(card));
                total = g.getHostTotal();
              }
              
              card = Blackjacking.getCardForValue(hit);
              
              if (card.contains("Clubs")) { emote = ":clubs:";
              }
              else if (card.contains("Hearts")) { emote = ":hearts:";
              }
              else if (card.contains("Spade")) { emote = ":spades:";
              }
              else if (card.contains("Diamond")) { emote = ":diamonds:";
              }
              if (total > 21) {
                Blackjacking.removeGame(g);
                
                channel.sendMessage(":no_entry: " + emote + " **[" + author.getAsMention() + "]** was dealt a(n) **[" + card + "]** card and now has a total of **[" + total + "]** " + emote + " :no_entry:").queue();
              } else {
                channel.sendMessage(emote + " **[" + author.getAsMention() + "]** was dealt a(n) **[" + card + "]** card and now has a total of **[" + total + "]** " + emote).queue();
              }
              
              if ((g.isHostTurn()) && (g.getOpponentTotal() > g.getHostTotal())) {
                Blackjacking.removeGame(g);
                
                if (Rigs.bjRigs.containsKey(g.getHost().toLowerCase())) Rigs.bjRigs.remove(g.getHost().toLowerCase());
                if (Rigs.bjRigs.containsKey(g.getOpponent().toLowerCase())) { Rigs.bjRigs.remove(g.getOpponent().toLowerCase());
                }
                if (total > 21) {
                  channel.sendMessage(":medal: **[" + author.getAsMention() + "]** has busted, **[" + g.getOpponent() + "]** won the game of blackjack :medal:").queue();
                } else {
                  channel.sendMessage(":medal: **[" + author.getAsMention() + "]** has beat the total of **[" + g.getOpponent() + "]**, **[" + author.getAsMention() + "]** won the game of blackjack :medal:").queue();
                }
              }
            }
          }
        }
        else if (msg.equalsIgnoreCase("!stay")) {
          if (Blackjacking.inGame(e.getMember().getEffectiveName())) {
            BlackjackGame g = Blackjacking.getGame(e.getMember().getEffectiveName());
            
            if ((g != null) && (g.getOpponent().equalsIgnoreCase(e.getMember().getEffectiveName()))) {
              g.setHostTurn(true);
              channel.sendMessage(":white_check_mark: **[" + author.getAsMention() + "]** chose to stay at **[" + g.getHostTotal() + "]** :white_check_mark:").queue();
            }
          }
        } else if ((msg.equalsIgnoreCase("!roulette")) && (isStaff(e.getMember()))) {
          String name = e.getMember().getEffectiveName().toLowerCase();
          
          int r = random(0, 38);
          String color = "";
          String emote = "";
          
          if (Rigs.rouletteRigs.containsKey(name)) {
            r = ((Integer)Rigs.rouletteRigs.get(name)).intValue();
            
            Rigs.rouletteRigs.remove(name);
          }
          
          if (r == 0) {
            color = "Green";
            emote = ":green_heart:";
          }
          else if (r % 2 == 0)
          {
            color = "Red";
            emote = ":heart:";
          }
          else {
            color = "Black";
            emote = ":black_heart:";
          }
          

          channel.sendMessage(emote + " **[" + author.getAsMention() + "]** spun the roulette wheel and the ball landed on **[" + r + "] [" + color + "]** " + emote).queue();
        }
        





        if ((msg.equalsIgnoreCase("!reset")) || (msg.equalsIgnoreCase("!clear"))) {
          if (!isStaff(e.getMember())) { return;
          }
          Dueling.clearDuels();
          Blackjacking.clearGames();
          Rigs.clearRigs();
          giveaway.clear();
          giveawayActive = false;
          
          channel.sendMessage("**[NOTICE]**\nAll queues have been reset.").queue();
        } else if ((msg.equalsIgnoreCase("!maxbet")) || (msg.equalsIgnoreCase("!maxbets")) || (msg.equalsIgnoreCase("!rank")) || (msg.equalsIgnoreCase("!ranks"))) {
          channel.sendMessage("Please message <@319136230803767297> to purchase a rank.").queue();
        }
        else if ((msg.equalsIgnoreCase("!site")) || (msg.equalsIgnoreCase("!Website"))) {
          channel.sendMessage("Our Website Is Here (https://venture07.alloja.net)").queue();
        } else if (msg.equalsIgnoreCase("!cashin")) {
          channel.sendMessage("Please if you want to cash in contact with .... <@319136230803767297> - <@173294860063735808> - <@299693897859465228> - <@439519217784717359> - <@260485852935880705> - <@455548643278061569>").queue();
        } else if (msg.equalsIgnoreCase("!cashout")) {
          channel.sendMessage("Please if you want to cash out contact with ... <@319136230803767297> - <@173294860063735808> - <@299693897859465228> - <@439519217784717359> - <@260485852935880705> - <@455548643278061569>").queue();
        } else if ((msg.equalsIgnoreCase("@VentureDice 2.0")) || (msg.equalsIgnoreCase("!info")))
        {


          EmbedBuilder eb1 = new EmbedBuilder();
          eb1.setTitle("Welcome To VentureDice ", null);
          eb1.setColor(Color.orange);
          eb1.setColor(new Color(16744448));
          eb1.setColor(new Color(219, 139, 0));
          eb1.setDescription("Hi ," + author.getAsMention() + "\r\n" + 
            "***The Best Trusted Dice Discord Server Since 2015***\r\n" + 
            "We have paid 10b ~ 15b in (07) and 700m in (rs3) \r\n" + 
            "Please make sure to go to our <#413797390978383872> channel to check it \r\n" + 
            "Our Staff : \r\n" + 
            "<@319136230803767297> is our admin (owner)\r\n" + 
            "<@260485852935880705> is our co-owner\r\n" + 
            "<@173294860063735808> is our 2nd owner\r\n" + 
            "<@299693897859465228> is our main scripter and developer\r\n" + 
            "<@439519217784717359> is our second developer\r\n" + 
            "If you need any help please make sure to pm anyone of them :smiley:" + "\r\n" + 
            "**For More Help Type !help**");
          eb1.addBlankField(false);
          channel.sendMessage(eb1.build()).queue();

        }
        else if ((msg.equalsIgnoreCase("!commands")) || (msg.equalsIgnoreCase("!help")) || (msg.equalsIgnoreCase("!cmds")))
        {

          EmbedBuilder eb1 = new EmbedBuilder();
          eb1.setTitle("Commands :sos: ", null);
          eb1.setColor(Color.orange);
          eb1.setColor(new Color(16744448));
          eb1.setColor(new Color(219, 139, 0));
          eb1.setDescription("!rank(s) - !maxbet ***(To Purchase A Rank)***\n!roll ***(To Roll The Dice)***\n!dd ***(To Roll Duel Dice)***\n!oe ***(To Hit A Guard)***\n!flower ***(To Pick A Flower)***\n!fp ***(To Pick Much Flowers)***\n!duel [@username] ***(To Commence A Duel)***\n!bj [@username] ***(To Start A BlackJack Game)***\n!hit ***(To Hit Your Opponent (Only In BlackJack Game)***\n!stay ***(To Stay (Only In BlackJack Game)***\n!cchest - !rchest - !gchest - !dchest - !3achest ***(Open Chest)***\n");
          eb1.addField("***NEW 2.0*** :", "!register ***(To Register In Wallet System)***\n!w ***(To View Your Wallet's Balance)***\n!send07 [@username] [amount] ***Send 07 Token(s)***\n!sendrs3 [@username] [amount] ***Send RS3 Token(s)***\n!cw [@username] ***(To Check Someone's Wallet Balance)***\n!staff ***(To Check Staff Members)***\n!status - !stats ***(To Check Bot's Systems Status)***\n!flip ***(To Flip A Coin)***\n!swap ***(To Swap Your Balance OSRS <-> RS3)***\n!exchange ***(To Exchange Your Balance)***", false);
          eb1.addBlankField(false);
          eb1.setThumbnail("https://cdn.discordapp.com/attachments/332635571111329795/461185032489533460/download_-_Copy.png");
          channel.sendMessage(eb1.build()).queue();
        }
        else if ((msg.equalsIgnoreCase("!status")) || (msg.equalsIgnoreCase("!stats")))
        {

          EmbedBuilder eb1 = new EmbedBuilder();
          eb1.setTitle("Bot Status !", null);
          eb1.setColor(Color.orange);
          eb1.setColor(new Color(16744448));
          eb1.setColor(new Color(219, 139, 0));
          eb1.addField("***GAMES SYSTEM*** :", "On", false);
          eb1.addBlankField(false);
          eb1.setThumbnail("https://cdn.discordapp.com/attachments/332635571111329795/461185032489533460/download_-_Copy.png");
          channel.sendMessage(eb1.build()).queue();

        }
        else if (msg.equalsIgnoreCase("!giveaway")) {
          if ((isStaff(e.getMember())) && (!giveawayActive)) {
            giveawayActive = true;
            
            giveawayCreator = author.getAsMention();
            
            channel.sendMessage("**@everyone A Giveaway has commenced! Do !join to enter the giveaway.**").queue();
          }
        } else if (msg.equalsIgnoreCase("!join")) {
          if (giveawayActive) {
            giveaway.add(author.getName());
            
            channel.sendMessage("**[" + author.getAsMention() + "]** has entered into the current giveaway.").queue();
          }
        } else if (msg.equalsIgnoreCase("!staff"))
        {

          EmbedBuilder eb1 = new EmbedBuilder();
          eb1.setTitle("Staff Members : ", null);
          eb1.setColor(Color.red);
          eb1.setColor(new Color(16744448));
          eb1.setColor(new Color(219, 139, 0));
          eb1.setAuthor(null, null, "https://media.discordapp.net/attachments/332635571111329795/461187902387519508/10qhzb8.png");
          eb1.addField("***Our Owner(s) : ***", "<@319136230803767297> & <@173294860063735808>", false);
          eb1.addField("***Our Co-Owner : ***", "<@260485852935880705>", false);
          eb1.addField("***Our Developer(s) : ***", "<@299693897859465228> - <@439519217784717359>", false);
          eb1.addField("***Our Web Developer : ***", "<@281459549699833858>", false);
          eb1.addBlankField(false);
          eb1.setThumbnail("https://cdn.discordapp.com/attachments/332635571111329795/461185032489533460/download_-_Copy.png");
          channel.sendMessage(eb1.build()).queue();
        }
        else if (msg.equalsIgnoreCase("!pickwinner")) {
          if ((isStaff(e.getMember())) && (giveawayActive)) {
            String winner = (String)giveaway.get(random(0, giveaway.size()));
            User u = getUser(winner);
            
            if (u == null) { return;
            }
            channel.sendMessage("**[" + u.getAsMention() + "]** won the giveaway! Ask **[" + giveawayCreator + "]** where to meet in game to claim your prize!").queue();
            
            giveawayActive = false;
          }
        } else if ((msg.equalsIgnoreCase("!afk")) && (isStaff(e.getMember()))) {
          channel.sendMessage("***" + author.getAsMention() + "*** is AFK Now !").queue();
        } else if ((msg.equalsIgnoreCase("!copyright")) || (msg.equalsIgnoreCase("!maker"))) {
          channel.sendMessage("**(Old Bot Was Developed By Prozen) New 2.0 Bot Is Developed by <@299693897859465228>, you can find him at fb.com/xkEm0x**").queue();
        } else if ((msg.equalsIgnoreCase("!setprivate")) && (author.getName().equalsIgnoreCase("~ k e M o ~")) && (isStaff(e.getMember()))) {
          Constants.PRIVATE = !Constants.PRIVATE;
        }
      }
    }
  }
  
  public Channel getTextChannel(JDA jda, String channelName) {
    for (TextChannel c : jda.getTextChannels()) {
      if (c.getName().equalsIgnoreCase(channelName)) { return c;
      }
    }
    return null; }
  
  public User getUser(String name) { User u;
    label47:
    for (Iterator localIterator = jda.getUsers().iterator(); localIterator.hasNext(); 
        return u)
    {
      u = (User)localIterator.next();
      if ((u == null) || (!u.getName().equalsIgnoreCase(name)))
        break label47;
    }
    return null;
  }
  
  public Member getMemberFromChannel(Channel c, String name) {
    for (Member m : c.getMembers()) {
      if (m.getUser().getName().equalsIgnoreCase(name)) { return m;
      }
    }
    return null;
  }
  
  public boolean isStaff(Member m) {
    return hasRole(m, "HOST");
  }
  
  public boolean hasRole(Member m, String roleName) {
    for (net.dv8tion.jda.core.entities.Role role : m.getRoles()) {
      if (role.getName().equalsIgnoreCase(roleName)) {
        return true;
      }
    }
    return false;
  }
  
  public int random(int min, int max) {
    return r.nextInt(max) + min;
  }
}
