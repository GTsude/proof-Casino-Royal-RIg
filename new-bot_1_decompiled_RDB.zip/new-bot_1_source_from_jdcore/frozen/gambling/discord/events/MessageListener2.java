package frozen.gambling.discord.events;

import frozen.gambling.discord.Constants;
import frozen.gambling.discord.Rigs;
import frozen.gambling.discord.games.BlackjackGame;
import frozen.gambling.discord.games.Blackjacking;
import frozen.gambling.discord.games.DiceDuelGame;
import frozen.gambling.discord.games.Dueling;
import frozen.gambling.discord.games.FlowerGame;
import frozen.gambling.discord.games.OddEvenGame;
import frozen.gambling.discord.games.RollGame;
import frozen.gambling.discord.games.WhipDuel;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.entities.Channel;
import net.dv8tion.jda.core.entities.ChannelType;
import net.dv8tion.jda.core.entities.Member;
import net.dv8tion.jda.core.entities.Message;
import net.dv8tion.jda.core.entities.MessageChannel;
import net.dv8tion.jda.core.entities.Role;
import net.dv8tion.jda.core.entities.TextChannel;
import net.dv8tion.jda.core.entities.User;
import net.dv8tion.jda.core.events.message.MessageReceivedEvent;
import net.dv8tion.jda.core.requests.restaction.MessageAction;

public class MessageListener2 extends net.dv8tion.jda.core.hooks.ListenerAdapter
{
  private JDA jda;
  private Random r = new Random();
  
  private boolean giveawayActive;
  
  private String giveawayCreator;
  
  private ArrayList<String> giveaway = new ArrayList();
  
  public MessageListener2() {}
  
  public void onMessageReceived(MessageReceivedEvent e) { jda = e.getJDA();
    
    User author = e.getAuthor();
    Message message = e.getMessage();
    MessageChannel channel = e.getChannel();
    
    String parsedName = author.getName().replaceAll("\\s+", "");
    String msg = message.getContentDisplay();
    
    boolean isBot = author.isBot();
    
    String timestamp = new SimpleDateFormat("EEEE @ hh:mm a").format(new java.util.Date());
    
    if (!isBot) {
      if ((Constants.PRIVATE) && (!author.getName().equalsIgnoreCase("Prozen"))) { return;
      }
      if (channel.getType().equals(ChannelType.PRIVATE)) {
        Channel c = getTextChannel(jda, "general");
        Member m = getMemberFromChannel(c, parsedName);
        
        System.out.println(parsedName);
        
        if ((!author.getName().equalsIgnoreCase("arnold")) && 
          (!isStaff(m))) {
          System.out.println(parsedName);
          return;
        }
        

        msg = msg.toLowerCase();
        
        String[] args = msg.split(" ");
        
        if (args.length == 3) {
          String username = args[0];
          String game = args[1];
          String textValue = args[2];
          
          int value = 0;
          
          if (game.equalsIgnoreCase("roll")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 100)) {
              Rigs.rollRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("dd")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 12)) {
              Rigs.ddRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("oe")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 22)) {
              Rigs.oeRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("flower")) {
            if (textValue.equalsIgnoreCase("hot")) {
              Rigs.flowerRigs.put(username, Integer.valueOf(1));
            } else if (textValue.equalsIgnoreCase("cold")) {
              Rigs.flowerRigs.put(username, Integer.valueOf(2));
            } else if (textValue.equalsIgnoreCase("host")) {
              Rigs.flowerRigs.put(username, Integer.valueOf(3));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("cchest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.cchestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("rchest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.rchestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("dchest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.dchestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("gchest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.gchestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("3achest")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 4)) {
              Rigs.ageChestRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("stake")) {
            if (textValue.equalsIgnoreCase("win")) {
              Rigs.stakeRigs.put(username, Integer.valueOf(1));
            } else if (!textValue.equalsIgnoreCase("lose"))
            {

              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("bj")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 1) && (value <= 10)) {
              Rigs.bjRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else if (game.equalsIgnoreCase("fp")) {
            if (textValue.equalsIgnoreCase("1p")) {
              Rigs.fpRigs.put(username, Integer.valueOf(1));
            } else if (textValue.equalsIgnoreCase("2p")) {
              Rigs.fpRigs.put(username, Integer.valueOf(2));
            } else if (textValue.equalsIgnoreCase("3oak")) {
              Rigs.fpRigs.put(username, Integer.valueOf(3));
            } else if (textValue.equalsIgnoreCase("4oak")) {
              Rigs.fpRigs.put(username, Integer.valueOf(4));
            } else if (textValue.equalsIgnoreCase("5oak")) {
              Rigs.fpRigs.put(username, Integer.valueOf(5));
            }
          } else if (game.equalsIgnoreCase("spin")) {
            value = Integer.parseInt(textValue);
            
            if ((value >= 0) && (value <= 38)) {
              Rigs.rouletteRigs.put(username, Integer.valueOf(value));
            } else {
              channel.sendMessage("[ERROR] Invalid value.").queue();
            }
          }
          else {
            channel.sendMessage("[ERROR] Invalid game.").queue();
            return;
          }
          
          if (value == 0) {
            channel.sendMessage("[RIG] Registered Rig Successfully - (" + username + ", " + game + ", " + textValue + ")").queue();
          } else {
            channel.sendMessage("[RIG] Registered Rig Successfully - (" + username + ", " + game + ", " + value + ")").queue();
          }
        } else {
          channel.sendMessage("[ERROR] Invalid Syntax. Example Usage - @username game value").queue();
        }
      }
      else
      {
        if (msg.equalsIgnoreCase("!rules"))
        {







          channel.sendMessage("**Current Rules:**\n\n\n-!bjrules (blackjack)\n\n-!rollrules (54x2 rules)\n\n-!oerules (odd/even)\n\n-!ddrules (dice duel)\n\n-!flowerrules (hot cold)\n\n-!chestrules (Chest games)\n\n-!fprules (flower poker)\n\n-!whiprules (staking)").queue();
        } else if (msg.equalsIgnoreCase("!bjrules"))
        {

          channel.sendMessage("**Blackjack Rules:**\n\nClosest to 21 wins, over 21 is bust (lose).\nStart by gambler typing !bj and adding card values (face cards worth 10, ace worth 1). Type !hit to be dealt another card and tell dealer/house, !stay to keep current value.").queue();
        } else if (msg.equalsIgnoreCase("!rollrules"))
        {



          channel.sendMessage("**54x2 Rules:**\n\nHost rolls a percentile (1-100) die.\n1-54, host wins.\n55-100, gambler wins.\nX2 payout.").queue();
        } else if (msg.equalsIgnoreCase("!oerules"))
        {




          channel.sendMessage("**Odd/Even Rules:**\n\nHost rolls a hits a guard (1-22) and gambler guesses odd or even.\nOdd: 3,5,7,9,11,13,15,17,19,21\nEven: 54,6,8,10,12,14,16,18,20,22\nHost Win: 1,2X2 Payout.").queue();
        } else if (msg.equalsIgnoreCase("!ddrules"))
        {


          channel.sendMessage("**Dice Duel Rules:****Dice Duel Rules:**\n\nHost and gambler both roll two-six sided (2-12) dice with !dd command.\nHighest roll wins with 10% commission on the pot and tie being host win. 10% commission with unlimited rolls when wagered (see !wagerrules for info).\nX2 Payout and 1x Tie = Host win").queue();
        } else if (msg.equalsIgnoreCase("!flowerrules"))
        {



          channel.sendMessage("**Hot/Cold Rules:**\n\nGambler bets if flower picked by host is a hot or cold color, (rainbow a is host win).\nHot: Red, Yellow, Orange.\nCold: Blue, Pastel, Purple.\nX2 Payout").queue();
        } else if (msg.equalsIgnoreCase("!fprules"))
        {


          channel.sendMessage("**Flower Poker Rules:**\n\nBet on who has the best hand of 5 flowers, command is !fp. Worst to best hands are:\nBust (no same colors) < 1 Pair < 2 Pair < 3 Of A Kind < Full House (3oak & 1 pair) < 4 Of A Kind < 5 Of A Kind.\nX2 Tie is host win.").queue();
        } else if (msg.equalsIgnoreCase("!whiprules"))
        {
          channel.sendMessage("**Whip Rules:**\n\nGambler and host will both start with 99hp, host gets PID (so will start the game and get last hit).  Minimum hit is 0, Max hit is 25. Game is started by host doing !duel, gambler does !whip, ends when either player is 0 HP.").queue();
        } else if (msg.equalsIgnoreCase("!chestrules"))
        {
          channel.sendMessage("**Chest Rules:**\n\nChest games are always winners! Win the shown prize after a host does the respective command, you can pick from these choices: Clue - 500k buy-in [!cchest], Rune - 1m buy-in [!rchest], Dragon - 2m buy-in [!dchest], God - 5m buy-in [!gchest], Third Age - 50m buy-in [!3achest]. Pricing listed is for OldSchool Runescape, for RS3 pricing simply PM a host.").queue();
        } else if (msg.equalsIgnoreCase("!wagerrules"))
        {
          channel.sendMessage("**Wagers:**\n\nWagers must be placed through a ranked host DO NOT DIRECTLY TRADE ANY GAMBLER YOUR CASH. Ranks will take a 10% commision for middlemanning a wager and payout to the respective winner.").queue();
        } else if (msg.equalsIgnoreCase("!rouletterules")) {
          channel.sendMessage("Gambler bets on Green [0], Black [odd numbers], Red [even numbers]. Green = 3x Payout, Black & Red = 2x Payout").queue();
        }
        




        if (msg.equalsIgnoreCase("!roll")) {
          RollGame g = new RollGame(e.getMember().getEffectiveName().toLowerCase());
          
          if (g.getResult() >= 55) {
            channel.sendMessage("**Roll The Dice**\n\n :white_check_mark:  :game_die: [" + author.getAsMention() + "] rolled a **[" + g.getResult() + "]** on the percentile dice **[1-100]** :game_die:  :white_check_mark: <:pic1:424588196391813120>\n\n\n " + timestamp).queue();
          } else {
            channel.sendMessage("\n\n :no_entry:  :game_die: [" + author.getAsMention() + "] rolled a **[" + g.getResult() + "]** on the percentile dice **[1-100]** :game_die:  :no_entry: <:pic1:424588196391813120>\n\n\n " + timestamp).queue();
          }
        } else if (msg.equalsIgnoreCase("!dd")) {
          DiceDuelGame g = new DiceDuelGame(e.getMember().getEffectiveName().toLowerCase());
          
          channel.sendMessage(":game_die: [" + author.getAsMention() + "] rolled a **[" + g.getResult() + "]** on the dueling dice **[1-12]** :game_die:").queue();
        } else if (msg.equalsIgnoreCase("!oe")) {
          OddEvenGame g = new OddEvenGame(e.getMember().getEffectiveName().toLowerCase());
          
          channel.sendMessage(":crossed_swords: [" + author.getAsMention() + "] hit a **[" + g.getResult() + "]** on the guard **[1-22 HP]** :crossed_swords:").queue();
        } else if (msg.equalsIgnoreCase("!flower")) {
          FlowerGame g = new FlowerGame();
          
          String name = e.getMember().getEffectiveName().toLowerCase();
          
          String flower = Constants.FLOWERS[g.getResult()];
          String flowerType = g.getFlowerType(flower);
          
          if (Rigs.flowerRigs.containsKey(name)) {
            int value = ((Integer)Rigs.flowerRigs.get(name)).intValue();
            
            switch (value) {
            case 1: 
              flower = Constants.HOT_FLOWERS[random(0, Constants.HOT_FLOWERS.length - 1)];
              break;
            
            case 2: 
              flower = Constants.COLD_FLOWERS[random(0, Constants.COLD_FLOWERS.length - 1)];
              break;
            
            case 3: 
              flower = "Rainbow";
            }
            
            
            flowerType = g.getFlowerType(flower);
            
            Rigs.flowerRigs.remove(name);
          }
          
          channel.sendMessage(":sunflower: [" + author.getAsMention() + "] picked a **[" + flower + "]** **(" + flowerType + ")** Flower :sunflower:").queue();
        } else if (msg.equalsIgnoreCase("!fp")) {
          String[] flowers = { Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
          String flower = Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)];
          
          if (Rigs.fpRigs.containsKey(e.getMember().getEffectiveName().toLowerCase())) {
            int value = ((Integer)Rigs.fpRigs.get(e.getMember().getEffectiveName().toLowerCase())).intValue();
            
            switch (value) {
            case 1: 
              if (random(1, 2) == 1) {
                flowers = new String[] { flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              } else {
                flowers = new String[] { Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], flower, flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              }
              break;
            
            case 2: 
              String f1 = Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)];
              flowers = new String[] { flower, flower, f1, f1, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              break;
            
            case 3: 
              flowers = new String[] { flower, flower, flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)], Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              break;
            
            case 4: 
              flowers = new String[] { flower, flower, flower, flower, Constants.FLOWERS[random(0, Constants.FLOWERS.length - 1)] };
              break;
            
            case 5: 
              flowers = new String[] { flower, flower, flower, flower, flower };
            }
            
            
            Rigs.fpRigs.remove(e.getMember().getEffectiveName().toLowerCase());
          }
          
          channel.sendMessage(":sunflower: [" + author.getAsMention() + "] picked **[" + flowers[0] + "] - [" + flowers[1] + "] - [" + flowers[2] + "] - [" + flowers[3] + "] - [" + flowers[4] + "]** flowers :sunflower:").queue();
        } else if ((msg.toLowerCase().startsWith("!duel")) && (isStaff(e.getMember()))) {
          if (msg.contains("@")) {
            String target = msg.substring(7);
            
            if ((target != null) && 
              (!Dueling.inDuel(author.getName())) && (!Dueling.inDuel(target))) {
              WhipDuel duel = new WhipDuel(e.getMember().getEffectiveName(), target);
              
              Dueling.addDuel(duel);
              
              int hit = random(0, 25);
              
              duel.hitOpponent(hit);
              
              channel.sendMessage(":crossed_swords: [" + author.getAsMention() + "] commenced a duel with **[" + target + "]** and hit a **[" + hit + "]**, **[" + target + "]** has **[" + duel.getOpponentHP() + " HP]** left :crossed_swords:").queue();
            }
          }
        }
        else if (msg.equalsIgnoreCase("!whip")) {
          String name = e.getMember().getEffectiveName();
          if (Dueling.inDuel(name)) {
            WhipDuel duel = Dueling.getDuel(name);
            
            if (duel != null) {
              if (duel.getHost().equalsIgnoreCase(name)) {
                if (duel.isHostTurn()) {
                  int hit = random(0, 25);
                  
                  hit = duel.hitOpponent(hit);
                  
                  channel.sendMessage(":crossed_swords: [" + author.getAsMention() + "] hit a **[" + hit + "]** on **[" + duel.getOpponent() + "]**, **[" + duel.getOpponent() + "]** now has **[" + duel.getOpponentHP() + " HP]** left :crossed_swords:").queue();
                  
                  if (duel.getOpponentHP() <= 0) {
                    Dueling.removeDuel(duel);
                    channel.sendMessage(":first_place: [" + duel.getHost() + "] won the duel against [" + duel.getOpponent() + "] :first_place:").queue();
                  }
                }
              } else if ((duel.getOpponent().equalsIgnoreCase(name)) && 
                (!duel.isHostTurn())) {
                int hit = random(0, 25);
                
                hit = duel.hitHost(hit);
                
                channel.sendMessage(":crossed_swords: [" + author.getAsMention() + "] hit a **[" + hit + "]** on **[" + duel.getHost() + "]**, **[" + duel.getHost() + "]** now has **[" + duel.getHostHP() + " HP]** left :crossed_swords:").queue();
                
                if (duel.getHostHP() <= 0) {
                  Dueling.removeDuel(duel);
                  channel.sendMessage(":first_place: **[" + duel.getOpponent() + "]** won the duel against **[" + duel.getHost() + "]** :first_place:").queue();
                }
              }
            }
          }
        }
        else if (msg.equalsIgnoreCase("!cchest")) {
          String item = Constants.CLUE_CHEST[random(0, Constants.CLUE_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.cchestRigs.containsKey(username)) {
            switch (((Integer)Rigs.cchestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.CLUE_CHEST_LEVEL_1[random(0, Constants.CLUE_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.CLUE_CHEST_LEVEL_2[random(0, Constants.CLUE_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.CLUE_CHEST_LEVEL_3[random(0, Constants.CLUE_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.CLUE_CHEST_LEVEL_4[random(0, Constants.CLUE_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.cchestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[Clue]** Chest :key:").queue();
        } else if (msg.equalsIgnoreCase("!rchest")) {
          String item = Constants.RUNE_CHEST[random(0, Constants.RUNE_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.rchestRigs.containsKey(username)) {
            switch (((Integer)Rigs.rchestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.RUNE_CHEST_LEVEL_1[random(0, Constants.RUNE_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.RUNE_CHEST_LEVEL_2[random(0, Constants.RUNE_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.RUNE_CHEST_LEVEL_3[random(0, Constants.RUNE_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.RUNE_CHEST_LEVEL_4[random(0, Constants.RUNE_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.rchestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[Rune]** Chest :key:").queue();
        } else if (msg.equalsIgnoreCase("!dchest")) {
          String item = Constants.DRAGON_CHEST[random(0, Constants.DRAGON_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.dchestRigs.containsKey(username)) {
            switch (((Integer)Rigs.dchestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.DRAGON_CHEST_LEVEL_1[random(0, Constants.DRAGON_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.DRAGON_CHEST_LEVEL_2[random(0, Constants.DRAGON_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.DRAGON_CHEST_LEVEL_3[random(0, Constants.DRAGON_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.DRAGON_CHEST_LEVEL_4[random(0, Constants.DRAGON_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.dchestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[Dragon]** Chest :key:").queue();
        } else if (msg.equalsIgnoreCase("!gchest")) {
          String item = Constants.GOD_CHEST[random(0, Constants.GOD_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.gchestRigs.containsKey(username)) {
            switch (((Integer)Rigs.gchestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.GOD_CHEST_LEVEL_1[random(0, Constants.GOD_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.GOD_CHEST_LEVEL_2[random(0, Constants.GOD_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.GOD_CHEST_LEVEL_3[random(0, Constants.GOD_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.GOD_CHEST_LEVEL_4[random(0, Constants.GOD_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.gchestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[God]** Chest :key:").queue();
        } else if (msg.equalsIgnoreCase("!3achest")) {
          String item = Constants.AGE_CHEST[random(0, Constants.AGE_CHEST.length - 1)];
          String username = e.getMember().getEffectiveName().toLowerCase();
          
          if (Rigs.ageChestRigs.containsKey(username)) {
            switch (((Integer)Rigs.ageChestRigs.get(username)).intValue()) {
            case 1: 
              item = Constants.AGE_CHEST_LEVEL_1[random(0, Constants.AGE_CHEST_LEVEL_1.length - 1)];
              break;
            
            case 2: 
              item = Constants.AGE_CHEST_LEVEL_2[random(0, Constants.AGE_CHEST_LEVEL_2.length - 1)];
              break;
            
            case 3: 
              item = Constants.AGE_CHEST_LEVEL_3[random(0, Constants.AGE_CHEST_LEVEL_3.length - 1)];
              break;
            
            case 4: 
              item = Constants.AGE_CHEST_LEVEL_4[random(0, Constants.AGE_CHEST_LEVEL_4.length - 1)];
            }
            
            
            Rigs.ageChestRigs.remove(username);
          }
          
          channel.sendMessage(":key: **[" + author.getAsMention() + "]** discovered: **[" + item + "]** in the **[3rd Age]** Chest :key:").queue();
        } else if ((msg.startsWith("!bj")) && (msg.contains("@")) && (isStaff(e.getMember()))) {
          String target = msg.substring(5);
          
          if (target != null) {
            BlackjackGame g = new BlackjackGame(e.getMember().getEffectiveName(), target);
            
            Blackjacking.addGame(g);
            
            channel.sendMessage("**[" + author.getAsMention() + "]** started a Blackjack game with **[" + target + "]**").queue();
          }
        } else if (msg.equalsIgnoreCase("!hit")) {
          if (Blackjacking.inGame(e.getMember().getEffectiveName())) {
            BlackjackGame g = Blackjacking.getGame(e.getMember().getEffectiveName());
            
            if (g != null) {
              String card = Constants.CARDS[random(0, Constants.CARDS.length - 1)];
              
              String emote = "";
              
              int total = 0;
              int hit = 0;
              
              if (card.contains("Clubs")) { emote = ":clubs:";
              }
              else if (card.contains("Hearts")) { emote = ":hearts:";
              }
              else if (card.contains("Spade")) { emote = ":spades:";
              }
              else if (card.contains("Diamond")) { emote = ":diamonds:";
              }
              if (g.isHostTurn()) {
                hit = g.hitOpponent(Blackjacking.getValueForCard(card));
                total = g.getOpponentTotal();
              } else {
                if (g.getHost().equalsIgnoreCase(e.getMember().getEffectiveName())) return;
                hit = g.hitHost(Blackjacking.getValueForCard(card));
                total = g.getHostTotal();
              }
              
              card = Blackjacking.getCardForValue(hit);
              
              if (card.contains("Clubs")) { emote = ":clubs:";
              }
              else if (card.contains("Hearts")) { emote = ":hearts:";
              }
              else if (card.contains("Spade")) { emote = ":spades:";
              }
              else if (card.contains("Diamond")) { emote = ":diamonds:";
              }
              if (total > 21) {
                Blackjacking.removeGame(g);
                
                channel.sendMessage(":no_entry: " + emote + " **[" + author.getAsMention() + "]** was dealt a(n) **[" + card + "]** card and now has a total of **[" + total + "]** " + emote + " :no_entry:").queue();
              } else {
                channel.sendMessage(emote + " **[" + author.getAsMention() + "]** was dealt a(n) **[" + card + "]** card and now has a total of **[" + total + "]** " + emote).queue();
              }
              
              if ((g.isHostTurn()) && (g.getOpponentTotal() > g.getHostTotal())) {
                Blackjacking.removeGame(g);
                
                if (Rigs.bjRigs.containsKey(g.getHost().toLowerCase())) Rigs.bjRigs.remove(g.getHost().toLowerCase());
                if (Rigs.bjRigs.containsKey(g.getOpponent().toLowerCase())) { Rigs.bjRigs.remove(g.getOpponent().toLowerCase());
                }
                if (total > 21) {
                  channel.sendMessage(":medal: **[" + author.getAsMention() + "]** has busted, **[" + g.getOpponent() + "]** won the game of blackjack :medal:").queue();
                } else {
                  channel.sendMessage(":medal: **[" + author.getAsMention() + "]** has beat the total of **[" + g.getOpponent() + "]**, **[" + author.getAsMention() + "]** won the game of blackjack :medal:").queue();
                }
              }
            }
          }
        }
        else if (msg.equalsIgnoreCase("!stay")) {
          if (Blackjacking.inGame(e.getMember().getEffectiveName())) {
            BlackjackGame g = Blackjacking.getGame(e.getMember().getEffectiveName());
            
            if ((g != null) && (g.getOpponent().equalsIgnoreCase(e.getMember().getEffectiveName()))) {
              g.setHostTurn(true);
              channel.sendMessage(":white_check_mark: **[" + author.getAsMention() + "]** chose to stay at **[" + g.getHostTotal() + "]** :white_check_mark:").queue();
            }
          }
        } else if ((msg.equalsIgnoreCase("!roulette")) && (isStaff(e.getMember()))) {
          String name = e.getMember().getEffectiveName().toLowerCase();
          
          int r = random(0, 38);
          String color = "";
          String emote = "";
          
          if (Rigs.rouletteRigs.containsKey(name)) {
            r = ((Integer)Rigs.rouletteRigs.get(name)).intValue();
            
            Rigs.rouletteRigs.remove(name);
          }
          
          if (r == 0) {
            color = "Green";
            emote = ":green_heart:";
          }
          else if (r % 2 == 0)
          {
            color = "Red";
            emote = ":heart:";
          }
          else {
            color = "Black";
            emote = ":black_heart:";
          }
          

          channel.sendMessage(emote + " **[" + author.getAsMention() + "]** spun the roulette wheel and the ball landed on **[" + r + "] [" + color + "]** " + emote).queue();
        }
        





        if ((msg.equalsIgnoreCase("!reset")) || (msg.equalsIgnoreCase("!clear"))) {
          if (!isStaff(e.getMember())) { return;
          }
          Dueling.clearDuels();
          Blackjacking.clearGames();
          Rigs.clearRigs();
          giveaway.clear();
          giveawayActive = false;
          
          channel.sendMessage("**[NOTICE] All queues have been reset.**").queue();
        } else if ((msg.equalsIgnoreCase("!maxbet")) || (msg.equalsIgnoreCase("!maxbets")) || (msg.equalsIgnoreCase("!ranks"))) {
          channel.sendMessage("Please message @Arnold to purchase a rank.").queue();
        } else if ((msg.equalsIgnoreCase("!commands")) || (msg.equalsIgnoreCase("!cmd")) || (msg.equalsIgnoreCase("!cmds")))
        {



















          channel.sendMessage("**Commands:**\n!rules\n!maxbet\n!ranks!roll\n!dd\n!oe\n!flower\n!fp\n!duel @username\n!whip\n!bj @username\n!hit\n!stay\n!cchest\n!rchest\n!dchest\n!gchest\n!3achest\n").queue();
        } else if (msg.equalsIgnoreCase("!giveaway")) {
          if ((isStaff(e.getMember())) && (!giveawayActive)) {
            giveawayActive = true;
            
            giveawayCreator = author.getAsMention();
            
            channel.sendMessage("**@everyone A Giveaway has commenced! Do !join to enter the giveaway.**").queue();
          }
        } else if (msg.equalsIgnoreCase("!join")) {
          if (giveawayActive) {
            giveaway.add(author.getName());
            
            channel.sendMessage("**[" + author.getAsMention() + "]** has entered into the current giveaway.").queue();
          }
        } else if (msg.equalsIgnoreCase("!pickwinner")) {
          if ((isStaff(e.getMember())) && (giveawayActive)) {
            String winner = (String)giveaway.get(random(0, giveaway.size()));
            User u = getUser(winner);
            
            if (u == null) { return;
            }
            channel.sendMessage("**[" + u.getAsMention() + "]** won the giveaway! Ask **[" + giveawayCreator + "]** where to meet in game to claim your prize!").queue();
            
            giveawayActive = false;
          }
        } else if ((msg.equalsIgnoreCase("!afk")) && (isStaff(e.getMember()))) {
          channel.sendMessage("**[" + author.getAsMention() + "]** is now AFK!").queue();
        } else if ((msg.equalsIgnoreCase("!copyright")) || (msg.equalsIgnoreCase("!maker")) || (msg.equalsIgnoreCase("!info"))) {
          channel.sendMessage("**This bot was developed by Prozen, you can find him at https://osbot.org/forum/profile/124926-prozen/**").queue();
        } else if ((msg.equalsIgnoreCase("!setprivate")) && (author.getName().equalsIgnoreCase("Prozen")) && (isStaff(e.getMember()))) {
          Constants.PRIVATE = !Constants.PRIVATE;
        }
      }
    }
  }
  
  public Channel getTextChannel(JDA jda, String channelName) {
    for (TextChannel c : jda.getTextChannels()) {
      if (c.getName().equalsIgnoreCase(channelName)) { return c;
      }
    }
    return null; }
  
  public User getUser(String name) { User u;
    label47:
    for (Iterator localIterator = jda.getUsers().iterator(); localIterator.hasNext(); 
        return u)
    {
      u = (User)localIterator.next();
      if ((u == null) || (!u.getName().equalsIgnoreCase(name)))
        break label47;
    }
    return null;
  }
  
  public Member getMemberFromChannel(Channel c, String name) {
    for (Member m : c.getMembers()) {
      if (m.getUser().getName().equalsIgnoreCase(name)) { return m;
      }
    }
    return null;
  }
  
  public boolean isStaff(Member m) {
    return hasRole(m, "HOST");
  }
  
  public boolean hasRole(Member m, String roleName) {
    for (Role role : m.getRoles()) {
      if (role.getName().equalsIgnoreCase(roleName)) {
        return true;
      }
    }
    return false;
  }
  
  public int random(int min, int max) {
    return r.nextInt(max) + min;
  }
}
